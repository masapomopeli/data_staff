<?php
//session_start();
	//hostname
	$hostname = 'localhost';
	
	//username
	$username = '';
	
	//password
	$password = '';

	//dbname
	$dbname = 'test';
	
	try
	{
		
		 
			$connection = new mysqli($hostname, $username, $password, $dbname);
			// Check connection
			if ($connection->connect_error) 
			{
				die("Connection failed: " . $connection->connect_error);
			}
			
			
			$name = $_POST['name'];
			$surname = $_POST['surname'];
			$id_number = $_POST['id_number'];
			$date_of_birth = $_POST['date_of_birth'];
			list($day,$month,$year)=preg_split('[/]',$date_of_birth);
			$new_date =$year.'/'.$month.'/'.$day; 
				
			$que = ("SELECT id_number FROM test.personal_info WHERE id_number='$id_number'"); 
			$query = mysql_query($que) or die($que."<br/><br/>".mysql_error());
			$status=0;
			while($row = mysql_fetch_row($query))
			{ 
				$status=1;
			}
			if($status==1)
			{
				echo "Sorry ID number ".$id_number." already exists in our database";
				?>
				<br><a href="index.html">go back to retry</a>
				<?php
			}
		    else
		    {
				$sql="INSERT INTO personal_info (name,surname,id_number,date_of_birth) VALUES ('$name','$surname','$id_number','$new_date')"; 
		
				if ($connection->query($sql) === TRUE) 
				{
					echo "New record created successfully";
				} 
				else
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
			}
	}
	catch (Exception $e)
	{
		throw new Exception( 'database not found', 0, $e);
	}
	?>