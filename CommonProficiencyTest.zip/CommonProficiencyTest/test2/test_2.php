<?php
if(isset($_POST['submit2']))
{
	header("Location:upload.php");
}
if(isset($_POST['submit1']))
{
	header('content-Type: text/csv;charset=utf-8');
	header('content-Disposition:attachement;filename=output.csv');

	$file = fopen('php://output','w');

	fputcsv($file,array('Id','Name','Surname','Initials','Age','DateOfBirth'));



	$names = array("Elliot","Smart","Victor","Lebo","Albert",
					"Thabiso","John","Mosca","Luke","Mathew",
					"Promise","Soft","Color","Long","Ntai",
					"David","Pashy","Lorenzo","Cumalo","Michael");
					
	$surname = array("Mopeli","Moreki","Tiiso","Handy","Bohloko",
					"Snyman","Mcpherson","Tool","Lucas","King",
					"Play","Hard","Green","Short","Madal",
					"Phoka","Eyes","Jeff","Buthelezi","Ncheba");



	//dates
	$list = array();
	$l_dates = array();
	$i = 0;
	while($i<100000)
	{
		$name1=$names[mt_rand(0,count($names)-1)];
		$surname1=$surname[mt_rand(0,count($surname)-1)];
		
		
		$year = mt_rand(1000,2017);
		$month= mt_rand(1,12);
		$day=mt_rand(1,28);
		$age=2017-$year;
		$random_date = $year."/".$month."/".$day;
		$list[$i]=$name1.",".$surname1;
		$l_dates[$i] =$random_date.",".$age; 
		$i++;
	}
	$l_names = array_unique($list);
	$u_dates = array_unique($l_dates);   
	$k = 0;
	$length = $_POST['length'];
	foreach($l_names as $view)
	{
		list($fname,$lname)=preg_split('[,]',$view);
		list($date_,$age_)=preg_split('[,]',$u_dates[$k]);
		$initials = $fname[0];//strip first char
		$k++;
		fputcsv($file,array("'".$k."'","'".$fname."'","'".$lname."'","'".$initials."'","'".$age_."'","'".$date_."'"));
		if($k==$length)
		{
			
			exit(0);
		}
		
	}


}

		



	?>