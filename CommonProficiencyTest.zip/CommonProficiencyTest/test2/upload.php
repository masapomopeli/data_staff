<!DOCTYPE html>
<html>

<body>
 
<div class=main style="width:100%;margin-left:auto;margin-right:auto">
<form role="form" action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" enctype="multipart/form-data">
 
	<input type="file" name="csv_file" id="csv_file">
	
	<div class="form-group">
    <input type="submit"   value="submit" name="submit">
	</div>
	 
</form> 
</div>
</body>
</html>


<?php
//session_start();
	//hostname
	$hostname = 'localhost';
	
	//username
	$username = '';
	
	//password
	$password = '';

	//dbname
	$dbname = 'test';
	
	try
	{
		
			$connection = new mysqli($hostname, $username, $password);
			@mysql_select_db($dbname)or die("unable to connect");
			
			//check if file is availuble****	
			$file = fopen("output.csv","r");
			$columns = fgetcsv($file,1000,",");
			//check if table exist 
			if(mysql_query("select 1 from csv_import"))
			{
				mysql_query('drop table csv_import');
			}
			$sql='create table test.csv_import(';
			for($i=0;$i<count($columns);$i++)
			{
				if($i==0)//primary key
				{
					$sql.=$columns[$i].' INTEGER(45) PRIMARY KEY,';
				}
				else if($columns[$i]=="DateOfBirth")
				{
					$sql.=$columns[$i].' DATE,';
				}
				else if($columns[$i]=="Age")
				{
					$sql.=$columns[$i].' INTEGER(45),';
				}
				else
				{	
					$sql.=$columns[$i].' VARCHAR(255),';
				}
			}
			$sql = substr($sql,0,strlen($sql)-1);
			$sql.=');'; 
			$d = 0;
			if($connection->query($sql)===true)//created
			{
				if($_FILES[csv_file][size]>0)
				{
				$file1=$_FILES[csv_file][tmp_name];
				$handle=fopen($file1,"r");
				 do
				 {
					 if($data[0]&&$d>1)
					 {
						 mysql_query("insert into csv_import(Id,Name,Surname,Initials,Age,DateOfBirth) values('".addslashes($data[0])
						 ."','".addslashes($data[1])
						 ."','".addslashes($data[2])
						 ."','".addslashes($data[3])
						 ."','".addslashes($data[4])
						 ."','".addslashes($data[5])
						 ."')");
						 
					 }
					
					 $d++;
					
				 }while($data=fgetcsv($handle,1000,",","''"));
				 $d=$d-2;
				 echo "<br>".$d." records inserted into database";
				}
			}
			else
			{
				echo "table not created check";
			}
			 

 
			
	}
	catch (Exception $e)
	{
		throw new Exception( 'database not found', 0, $e);
	}