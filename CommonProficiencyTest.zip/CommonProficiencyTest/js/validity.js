function validity_check()
{
	var name = document.forms["mydata"]["name"].value;
	var surname = document.forms["mydata"]["surname"].value;
	var id = document.forms["mydata"]["id_number"].value;
	var date = document.forms["mydata"]["date_of_birth"].value;
	
	var id_length = id.length;
	
	if(name==""||surname==""||id==""||date=="")//make sure all data is filled
	{
		alert("make sure you provide all required data");
		return false;
	}
	name_format = /^[A-za-z]+$/;
	if(!name.match(name_format))
	{
		alert("make sure your name is made of characters");
		return false;
	}
	if(!surname.match(name_format))
	{
		alert("make sure your surname is made of characters");
		return false;
	}
	if(id_length!=13||isNaN(id)==true)//validating id 
	{
		if(id_length!=13)
		{
			alert("Your ID number should be 13 digits");
		}
		if(isNaN(id)==true)
		{
			alert("make sure your id number is made up of numbers only");
		}
		return false;
	}
	//validate date
	c_format = /^\d{1,2}\/\d{1,2}\/\d{4}$/;//correct date format
	if(date!=''&&!date.match(c_format))//date incorrect
	{
		alert("incorrect date format "+date); 
		return false;
	}
	else//correct date
	{
		array_date = date.split("/");//get day,month and year separately
		day = parseInt(array_date[0]);month =parseInt(array_date[1]); year=parseInt(array_date[2]);
		if(day<1||day>31)
		{
			alert("Enter a valid day");
			return false;
		}
		if(month<1||month>12)
		{
			alert("Enter a valid month");
			return false;
		}
		if(year<1900||year>2017)
		{
			alert("Enter a valid year,it should be between 1900 and 2017");
			return false;
		}
		if(month<=7)//month mod2 = 1,implies it has 31 days,and 30%2==0 =>30days months
		{
			if(month%2==0)//30days months
			{
				if(month==2)//February
				{
					if(year%4==0&&day>29)//leap year(hence February has 29days)
					{
							alert("A february of a leap year is only 29days,please check your day");
							return false;
					}
					else//not a leap year
					{
						if(day>28)
						{
							alert("February have 28 days for a year of 365 days please recheck your day");
							return false;
						}
					}
				}
				else//any apart from Feb
				{
					if(day>30)
					{
						alert("this month has 30 days,make sure you are within the range");
						return false;
					}
					
				}
			}
			
		}
		else
		{
			if(month%2==1&&day>30)
			{
				alert("The "+month+"th month has up to 30 days please recheck your range");
				return false;
			}
			
		}
		if(day<=9)
		{
			day=0+day.toString();
		}
		else
		{
			day=day.toString();
		}
		if(month<=9)
		{
			month=0+month.toString();
		}
		else
		{
			month=month.toString();
		}
		year=year.toString();
		new_date = year[2]+year[3]+month+day;
		
		new_id = id.slice(0,6);
		if(new_date!=new_id)
		{
			alert("the first 6 numbers of your id_number should match your birth date,please recheck!");
			return false;
		}
	}
	//validate birth date with id_number

	
} 
function check()
{
	var length = document.forms["data"]["length"].value;
	if(length<1||length>400)
	{
		alert("please key in a number between 0 and 400");
		return false;
	}
}